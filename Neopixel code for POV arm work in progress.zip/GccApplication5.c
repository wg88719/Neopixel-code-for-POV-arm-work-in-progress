/*
 * $safeprojectname$.c
 *
 * Created: 8-9-2015 09:34:33
 *  Author: Ewoud Deenik
 */ 


#define  F_CPU  16000000
#include "bits.h"
#include "light_ws2812.h"
#include <avr/io.h> 
#include <util/delay.h>
#include <avr/interrupt.h>


#define MAXPIX 253
#define COLORLENGTH 10
#define FADE 5

struct cRGB colors[8];
struct cRGB led[MAXPIX];
struct pic	test[8];
int main(void)
{
	int TESTCOLOR = 0;
	uint8_t j = 1;
	uint8_t k = 1;
	int x;
	x = 0;
	unsigned int y;
	y = 0x7e;
	int status = 1;
	 
	 bit_clear(DDRB, DDB1);
	  
	
		
	if( y = 126){
			led[test[1].led].r=colors[test[1].color].r;
			led[test[1].led].g=colors[test[1].color].g;
			led[test[1].led].b=colors[test[1].color].b;
			
			
		
		_delay_ms(10);
		ws2812_sendarray((uint8_t *)led,MAXPIX*3);
		_delay_ms(10000);
	}

	DDRB|=_BV(ws2812_pin);
		
    uint8_t i;
    for(i=MAXPIX; i>0; i--)
    {    
        led[i-1].r=0;led[i-1].g=0;led[i-1].b=0;
    }
		
    //Rainbowcolors
    colors[0].r=150; colors[0].g=150; colors[0].b=150;
    colors[1].r=255; colors[1].g=000; colors[1].b=000;//red
    colors[2].r=255; colors[2].g=100; colors[2].b=000;//orange
    colors[3].r=100; colors[3].g=255; colors[3].b=000;//yellow
    colors[4].r=000; colors[4].g=255; colors[4].b=000;//green
    colors[5].r=000; colors[5].g=100; colors[5].b=255;//light blue (t�rkis)
    colors[6].r=000; colors[6].g=000; colors[6].b=255;//blue
    colors[7].r=100; colors[7].g=000; colors[7].b=255;//violet

		while(1){
			  	test[0].led=0; test[0].color=TESTCOLOR;
			  	test[1].led=1; test[1].color=TESTCOLOR;
			  	test[2].led=2; test[2].color=TESTCOLOR;
			  	test[3].led=3; test[3].color=TESTCOLOR;
			  	test[4].led=4; test[4].color=TESTCOLOR;
			  	test[5].led=5; test[5].color=TESTCOLOR;
			  	test[6].led=6; test[6].color=TESTCOLOR;
			  	test[7].led=7; test[7].color=TESTCOLOR;
				  
			for(x = 0; x <= 8; x ++){
			led[test[x].led].r=colors[test[x].color].r;
			led[test[x].led].g=colors[test[x].color].g;
			led[test[x].led].b=colors[test[x].color].b;
			
			
			
			}
				_delay_ms(10);
			ws2812_sendarray((uint8_t *)led,MAXPIX*3);
			if(bit_is_clear(PINB, PINB1))  {
				_delay_ms(1000);
				
							if(TESTCOLOR)
							
						}
					}
					
					
					
				}
				
				
				
		
		
		





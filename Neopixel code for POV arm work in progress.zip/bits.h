/* 
 * This is a set of macro's for register bit manipulation 
 * Written by VHZH for ESE
 */
 
#define F_CPU 16000000

#define bit_set(reg, bit) (reg |= _BV(bit))
#define bit_clear(reg, bit) (reg &= ~_BV(bit))
#define bit_toggle(reg, bit) (reg ^= _BV(bit))

//bit_is_set and bit_is_clear are already available
